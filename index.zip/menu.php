    <ul>
      <li><a href="index.php">Home</a></li>
      <li>Master</li>
        <ul>
          <li>User</li>
          <li>Venue</li>
          <!--<li>Template</li>-->
        </ul>
      <li><a href="tr__inev.php">Event</a></li>
      <!--<li>View</li>
        <ul>
          <li><a href="vw__evnt.php">View Event</a></li>
        </ul>-->
      <!-- <li>Report</li> -->
    </ul>