<?php


// konek database
include("tr__conn.php");


// simpan data di tabel transaksi
$msql = "
  update ".$_POST["namatb__"]." set ".$_POST["namafld_"]." = '".$_POST["namacust"].", ".$_POST["jml_pax_"].", ".$_POST["stts__"]."' where id__vnue = ".$_POST["id__vnue"]."
";
mysql_query($msql);
header("location: tr__show.php?namatb__=".$_POST["namatb__"]);
exit;
?>