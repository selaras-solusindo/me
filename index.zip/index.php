<html>
  <body>
    <?php include "menu.php"; ?>
  </body>
</html>