<?php


// konek database
include("tr__conn.php");


// ambil variabel
$mnamatb__ = $_GET["namatb__"];
$mid__vnue = $_GET["id__vnue"];
$mnamafld_ = $_GET["namafld_"];

$msql = "select * from ".$mnamatb__." where id__vnue = '".$mid__vnue."'";
$mquery = mysql_query($msql);
$row = mysql_fetch_array($mquery);
$mdata = explode(", ", $row[$mnamafld_]);
?>

<html>
  <body>
    <?php include "menu.php"; ?>
    <h2>Edit Data Event Tgl. <?php echo $_GET["tgblth__"]; ?></h2>
    <form method="post" action="tr__pro2.php">
      <input type="hidden" name="namatb__" value="<?php echo $_GET["namatb__"];?>">
      <input type="hidden" name="id__vnue" value="<?php echo $_GET["id__vnue"];?>">
      <input type="hidden" name="namafld_" value="<?php echo $_GET["namafld_"];?>">
      <table border="0">
        <tr>
          <td>Customer</td><td>:</td><td><input type="text" name="namacust" size="50" value="<?php echo $mdata[0]; ?>"></td>
        </tr>
        <tr>
          <td>Jumlah Pax</td><td>:</td><td><input type="text" name="jml_pax_" size="4" value="<?php echo $mdata[1]; ?>"></td>
        </tr>
        <tr>
          <td>Status</td><td>:</td>
          <td>
            <select name="stts__">
              <option value="1" <?php echo ($mdata[2] == 1 ? "selected" : ""); ?>>Confirm</option>
              <option value="2" <?php echo ($mdata[2] == 2 ? "selected" : ""); ?>>Tentative</option>
            </select>
          </td>
        </tr>
        <tr>
          <td>&nbsp;</td><td>&nbsp;</td><td><input type="submit" name="btn_sbmt" value="Submit"></td>
        </tr>
      </table>
    </form>
  </body>
</html>