<?php


// ambil variabel
$mnamatb__ = $_GET["namatb__"];
$mid__vnue = $_GET["id__vnue"];
$mnamafld_ = $_GET["namafld_"];
?>

<html>
  <body>
    <?php include "menu.php"; ?>
    <h2>Input Data Event Tgl. <?php echo $_GET["tgblth__"]; ?></h2>
    <form method="post" action="tr__proc.php">
      <input type="hidden" name="namatb__" value="<?php echo $_GET["namatb__"];?>">
      <input type="hidden" name="id__vnue" value="<?php echo $_GET["id__vnue"];?>">
      <input type="hidden" name="namafld_" value="<?php echo $_GET["namafld_"];?>">
      <table border="0">
        <tr>
          <td>Customer</td><td>:</td><td><input type="text" name="namacust" size="50"></td>
        </tr>
        <tr>
          <td>Jumlah Pax</td><td>:</td><td><input type="text" name="jml_pax_" size="4"></td>
        </tr>
        <tr>
          <td>Status</td><td>:</td><td><select name="stts__"><option value="1">Confirm</option><option value="2">Tentative</option></select></td>
        </tr>
        <tr>
          <td>&nbsp;</td><td>&nbsp;</td><td><input type="submit" name="btn_sbmt" value="Submit"></td>
        </tr>
      </table>
    </form>
  </body>
</html>