<?php


// konek database
include("tr__conn.php");


// pendefinisian nama tabel, tahun dan bulan
$mnamatb__ = $_GET["namatb__"];


// array nama bulan
$anamabln_ = array(
  1 => "Januari",
  "Februari",
  "Maret",
  "April",
  "Mei",
  "Juni",
  "Juli",
  "Agustus",
  "September",
  "Oktober",
  "November",
  "Desember"
  );


// array jumlah hari dalam satu bulan
$ajml_hari = array(1 => 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
// contoh tb_201508
$mthn_ = intval(substr($mnamatb__, 3, 4)); // 2015
$mbln_ = intval(substr($mnamatb__, -2)); // 08
if (($mbln_ == 2) and ($mthn_ % 4 == 0)) { // kabisat
  $mjml_hari = 29;
}
else {
  $mjml_hari = $ajml_hari[$mbln_];
}


// pengambilan record record tabel temporary template
$msql = "select * from ".$mnamatb__."";
$mquery = mysql_query($msql);
?>

<html>
  <head>
    <title>
    </title>
  </head>
  <body>
    <?php include "menu.php"; ?>
    <h1><?php echo $anamabln_[$mbln_] . " " . $mthn_;?></h1>
    <table border="1">
      <tr>
        <th>Venue</th>
        <?php for($i = 1; $i <= $mjml_hari; $i++) { ?>
        <th><?php echo substr("00".$i, -2); ?></th>
        <?php } ?>
      </tr>
      <?php while($row = mysql_fetch_array($mquery)) { ?>
      <tr>
        <td><?php echo $row["namavnue"]; ?></td>
        <?php for($i = 1; $i <= $mjml_hari; $i++) { ?>
        <?php   $mnamafld_ = "f_".substr("00".$i, -2); ?>
        <?php   if($row[$mnamafld_] == null) { ?>
        <td align="center"><a href="tb__ine2.php?namatb__=<?php echo $mnamatb__; ?>&id__vnue=<?php echo $row[id__vnue]; ?>&namafld_=<?php echo 'f_'.substr('00'.$i, -2); ?>&tgblth__=<?php echo substr('00'.$i, -2) . ' ' . $anamabln_[$mbln_] . ' ' . $mthn_;?>">_</a></td>
        <?php   }
                else {
                  $mdata = explode(", ", $row[$mnamafld_]);
                  $mdatashow = $mdata[0] . ", " . $mdata[1] . " pax, " . ($mdata[2] == 1 ? "Confirm" : "Tentative");
                  ?>
        <td align="center"><a href="tb__ine3.php?namatb__=<?php echo $mnamatb__; ?>&id__vnue=<?php echo $row[id__vnue]; ?>&namafld_=<?php echo 'f_'.substr('00'.$i, -2); ?>&tgblth__=<?php echo substr('00'.$i, -2) . ' ' . $anamabln_[$mbln_] . ' ' . $mthn_;?>"><?php echo $mdatashow; ?></a></td>
        <?php   }
              } ?>
      </tr>
      <?php } ?>
    </table>
  </body>
</html>